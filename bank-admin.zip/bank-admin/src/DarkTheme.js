import React from 'react';
import './dark.css'

const Theme = ()=>(<React.Fragment></React.Fragment>)

export default Theme